# Zemen Grid 2

Zemen Grid is a widget-first Ethiopian calendar desktop app. It runs as two independent floating surfaces:

- **Year grid** — a frameless Ethiopian-calendar heatmap that scales every cell to the available window size and never uses horizontal scrolling.
- **Local clock** — a separate 12-hour clock with explicit Amharic `ቀን` (day) and `ምሽት` (night) labels.

A small control center and system-tray menu turn either widget on or off. The ordinary app window is never required for the widgets to remain visible.

## Widget behavior

- Frameless, movable, and always-on-top
- Resize the width to set the scale; widget height automatically hugs its content
- Previous width and screen position are restored on the next launch
- High-contrast dark, light, or system theme with WCAG AA text colors
- Optional header, month labels, weekday labels, legend, date, seconds, and hover details
- Right-click either widget for quick controls
- Grid cells remain square, fill the available width, and never leave a tall empty window
- Click a day to open its persistent local note and color level
- Year, month, and week grid views
- Ethiopian-date deadline with hover countdown
- Tray menu for showing widgets, opening controls, or quitting

The default clock is never 24-hour:

- `06:00–17:59` → `ቀን`
- `18:00–05:59` → `ምሽት`

## Run on Windows

1. Install the current LTS version of [Node.js](https://nodejs.org/).
2. Double-click `START-ZEMEN-GRID.bat`.
3. On first launch, the desktop runtime is downloaded once.

To make a portable Windows executable, double-click `BUILD-WINDOWS.bat`. The result appears in `dist`.

## Controls

- Drag widgets from their padding or visible labels.
- Resize from any window edge.
- Right-click a widget for its most useful display settings.
- Click a grid cell to edit its note.
- Click the tray icon to reopen the control center.
- Closing the control center leaves the widgets running.

## Privacy and upgrades

Settings, window positions, deadlines, and notes stay in the normal per-user application-data folder. Version 2 automatically migrates notes and compatible appearance settings from version 1.

## Development

```bash
npm install
npm start
npm run verify
npm run build:windows
```

Automated tests cover Ethiopic conversion, Pagumen, leap years, full-year round trips, widget scaling, independent visibility, 12-hour day/night output, and shared note persistence.
